 <?php 
require_once('config.php');
				$query = "SELECT * FROM queue where q_status = 'Waiting' order by queue_id asc";

$results = mysql_query($query);

/* check whethere there were matching records in the table
by counting the number of results returned */


if(@mysql_num_rows($results) >= 1)

{
	?>
    
    <table class="table" border='1' align='center'>
      <thead>
                        <tr>
                         <th>Name</th>
                          <th>Queue</th>
						  <th>Position</th>
	    </tr>
      </thead>
                      <tbody>
					   <?php while($row = mysql_fetch_array($results))
	{
		$queue_id = $row['queue_id'];
		$q_name =  $row['q_name'];
		$q_number = $row['q_number'];
		$position = $row['position'];
		
			?>
                        <tr>
                          <td class="center"><?php echo $q_name; ?></td>
                          <td class="center"> # <?php echo $queue_id; ?></td>
						  <td class="center"><?php echo $position; ?></td>
                        </tr>
                       
                      
					  <?php 
				
	}
	
	?>
    </tbody>
    </table>
    
    <?php
	
}
else
	
	echo "<center><p><b>There are no Records <font color=#FF0000> at the Moment !!! </font> in the database.</p></b><img src='img/waiting.jpg' width='150px' height='150px'></center>";
?>
    
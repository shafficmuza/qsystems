<div id="left" class="foo">
                        
                        <!-- #menu -->
                        <ul id="menu" class="bg-blue dker">

                                  <li class="">
                                    <a href="start_day.php" target="new">
                                      <span class="link-title">&nbsp;Start Day</span>
                                    </a>
                                  </li>
                                 
                                  <li class="">
                                    <a href="manage_queue1.php">
                                      <span class="link-title">&nbsp;Manage Queue</span>
                                    </a>
                                  </li>

                                  <li class="">
                                    <a href="add_queue.php">
                                      <span class="link-title">&nbsp;Add Queue</span>
                                    </a>
                                  </li>

                                  <li class="">
                                    <a href="displayQ.php" target="new">
                                      <span class="link-title">&nbsp;Queue Display</span>
                                    </a>
                                  </li>
                                   
                                  
                                  
                                
                         </ul>
                        <!-- /#menu -->
                    </div>--
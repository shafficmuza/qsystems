<?php require_once("header.php");?>

<?php require_once("header-body.php");?>
<?php require_once("side_menu.php"); ?>
                    <!-- /#left -->
                <div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter">
                           
<?php 
require_once('config.php');
        $query = "SELECT * FROM queue order by queue_id asc";

$results = mysql_query($query);

/* check whethere there were matching records in the table
by counting the number of results returned */


if(@mysql_num_rows($results) >= 1)

{
  ?>
    </h1>
   <div id="collapse4" class="body">
                              <table id="dataTable" class="table table-bordered table-condensed table-hover table-striped">
                                  <thead>
                                  <tr>
                                      <th>Name</th>
                                      <th>Queue No</th>
                                      <th>Station No</th>
                                      <th>Action</th>
                                      <th>Action</th>
                                  </tr>
                                  </thead>
                                  <tbody>
             <?php while($row = mysql_fetch_array($results))
  {
    $queue_id = $row['queue_id'];
    $q_name =  $row['q_name'];
    $q_number = $row['q_number'];
    $position = $row['position'];
    $start_time = $row['start_time'];
    $end_time = $row['end_time'];
    $q_status = $row['q_status'];
    
    switch($start_button = $q_status)
  {
    case "Started": $start_button = "Re-Call";
    break;
    case "Completed": $start_button = "Completed";
    break;
    default: $start_button = "Started";
    }
    
      ?>
                                  <tr>
                                    <td class="center"><?php echo $q_name; ?></td>
                                    <td class="center"> # <?php echo $queue_id; ?></td>
                                    <td class="center"><?php echo $position; ?></td>
                                    <td class="center"><a href="call.php?status=Started&queue_id=<?php echo $queue_id;?>&position=<?php echo $position;?>"><?php echo $start_button;?></a></td>
                                    <td class="center"><a href="call.php?status=Completed&queue_id=<?php echo $queue_id;?>">Stop</a></td>
                                  </tr>

                       
                       
                      
            <?php 
        
  }
  
  ?>
                        </tbody>
                        </table>

                  </div>
    
    <?php
  
}
else
  
  echo "<h2>There are no Records <font color=#FF0000> at the Moment !!! </font> in the database.";
?>
<?php
if(isset($_GET['queue_id']))
{
  $queue_idx = $_GET['queue_id'];
  $positionx = $_GET['position'];

?>
           <center>
                                    <audio controls>
                                      <source src="voice/client/<?php echo $queue_idx.".mp3";?>" type="audio/mpeg">
                                      Your browser does not support the audio element.
                                    </audio>
                                    
                                    <audio controls>
                                      <source src="voice/position/<?php echo $positionx.".mp3";?>" type="audio/mpeg">
                                        Your browser does not support the audio element.
                                    </audio>
           </center>
           <?php
}
       ?>

       
                                          

                        <!-- /.inner -->
                    </div>
                    <!-- /.outer -->
                </div>
                <!-- /#content -->
                    
           
            <!-- /#wrap -->
           <?php require_once("footer.php");?>
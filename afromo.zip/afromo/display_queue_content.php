 <body bgcolor="#34495e">
 <?php 
require_once('config.php');
$query = "SELECT * FROM queue where q_status = 'Started' order by queue_id asc";

$results = mysql_query($query);
/* check whethere there were matching records in the table
by counting the number of results returned */

if(@mysql_num_rows($results) >= 1)

{
while($row = mysql_fetch_array($results))
	{
		$queue_id = $row['queue_id'];
		$q_name =  $row['q_name'];
		$q_number = $row['q_number'];
		$position = $row['position'];
	}


?>


<div class="col-sm-4"></div>
<div class="col-sm-4 display-queue-head">Afro n Mo</div>
<div class="col-sm-4"></div>

<div class="col-sm-12">

<div class="col-sm-3"></div>
<div class="col-sm-3 display-queue">Client No</div>
<div class="col-sm-3 display-queue">Station</div>
<div class="col-sm-3"></div>

</div>
<div class="col-sm-12">

<div class="col-sm-2"></div>
<div class="col-sm-4 display-queue-number" ><?php echo $queue_id; ?></div>

<div class="col-sm-4 display-queue-number"><?php echo $position; ?></div>
<div class="col-sm-2"></div>


</div>









<?php 
}
else
	
	echo "<center><h2>There are no Records <font color=#FF0000> at the Moment !!! </font> in the database.<br/><br/></br/><img src='img/waiting.jpg' width='250px' height='250px'></center>";


$query = "SELECT * FROM queue where q_status = 'Waiting' order by queue_id asc limit 1";

$results = mysql_query($query);
/* check whethere there were matching records in the table
by counting the number of results returned */

if(@mysql_num_rows($results) >= 1)

{
while($row = mysql_fetch_array($results))
  {
    $queue_id = $row['queue_id'];
    $q_name =  $row['q_name'];
    $q_number = $row['q_number'];
    $position = $row['position'];
  }
}



?>



<div class="col-sm-4"></div>
<div class="col-sm-4 display-queue-head">Waiting .. </div>
<div class="col-sm-4"></div>

<div class="col-sm-12">

<div class="col-sm-3"></div>
<div class="col-sm-3 display-queue">Client No</div>
<div class="col-sm-3 display-queue">Station</div>
<div class="col-sm-3"></div>

</div>
<div class="col-sm-12">

<div class="col-sm-4"></div>
<div class="col-sm-3" ><?php echo $queue_id; ?></div>

<div class="col-sm-2 "><?php echo $position; ?></div>
<div class="col-sm-3"></div>


</div>
    



</body>
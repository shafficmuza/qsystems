<?php session_start();?>
<?php require_once("header.php");?>

<?php require_once("header-body.php");?>
<?php require_once("side_menu.php"); ?>
                    <!-- /#left -->
                <div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter">
                           
<!-- end .content -->

					 <form id="form1" class="form-horizontal" name="form1" method="post" action="">

					 				 <?php
	if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
				echo '<div class="alert alert-info alert-icon">';
				foreach($_SESSION['ERRMSG_ARR'] as $msg) {
			echo $msg; 
		}
		echo ' <i class="icon">&#61845;</i>
                    </div>';
		unset($_SESSION['ERRMSG_ARR']);
	}
		?>

					                <div class="form-group">
					                    <label for="text1" class="control-label col-lg-4">Client Name:</label>

					                    <div class="col-lg-8">
					                        <input type="text"  name="client_name" id="text1" placeholder="Client Name" class="form-control">
					                    </div>
					                </div>

					                 <div class="form-group">
					                    <label for="text1" class="control-label col-lg-4">Station</label>
					                    
					                    <div class="col-lg-8">
					                        <input type="text" name="position" id="text1" placeholder="Station Number" class="form-control">
					                    </div>
					                </div>
									
									<div class="form-group">
										<div class="col-sm-6"></div>
										<div class="col-sm-6">
										<input type="submit" name="save" value="   Save  " class="btn btn-success">

					                <input type="reset" value="   Clear   " class="btn btn-danger"></div>
					               
					                </div>

					 </form>
   
    
    <?php
	if(isset($_POST['save']))
	{
    require_once('config.php');
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	//Sanitize the POST values  
	$q_name = clean($_POST['client_name']);
	$position = clean($_POST['position']);
	
	//Create INSERT query
	$qry = "INSERT INTO queue(q_name,position) VALUES('$q_name','$position')";
	$result = @mysql_query($qry) or die("Operation Failed Error 00017i cant insert Queue".mysql_error());
	
	//Check whether the query was successful or not
	if($result) {
		
		//echo "<font color='green'>Record Added Successfull !!!</font>";
		$errmsg_arr[] = "<font color='green'>Queue Added </font>";
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: add_queue.php");
		exit();
		
	}else {
		die("Query failed Correct Your Errors: ".mysql_error());
		}
		
}
	
	?>
       
                                          

                        <!-- /.inner -->
                    </div>
                    <!-- /.outer -->
                </div>
                <!-- /#content -->
                    
           
            <!-- /#wrap -->
           <?php require_once("footer.php");?>
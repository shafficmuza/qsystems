<?php 
require_once('config.php');
				$query = "SELECT * FROM queue order by queue_id asc";

$results = mysql_query($query);

/* check whethere there were matching records in the table
by counting the number of results returned */


if(@mysql_num_rows($results) >= 1)

{
	?>
	
                    <table class="table" border='1'>
                      <thead>
                        <tr>
                          
                          <th>Queue ID</th>
                          <th>Name</th>
                          <th>Queue No</th>
						  <th>Position No</th>
						  
                         
                        </tr>
                      </thead>
                      <tbody>
					   <?php while($row = mysql_fetch_array($results))
	{
		$queue_id = $row['queue_id'];
		$q_name =  $row['q_name'];
		$q_number = $row['q_number'];
		$position = $row['position'];
		
			?>
                        <tr>
                          <td><?php echo $queue_id; ?></td>
						  <td class="center"><?php echo $q_name; ?></td>
                          <td class="center"><?php echo $q_number; ?></td>
						  <td class="center"><?php echo $position; ?></td>
                            </tr>
                       
                      </tbody>
					  <?php 
				
	}
	// its time to echo the the table now
	//echo $output;
}
else
	
	echo "<h2>There are no Records <font color=#FF0000> at the Moment !!! </font> in the database.";
	?>
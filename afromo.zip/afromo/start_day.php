 <?php 
 require_once("config.php");
/*
 queue_id
 q_name
 position
 start_time
 end_time
 q_number
 operator_id
 q_status
 call
 */

					
		$query_update_history = mysql_query("insert into history_queue(q_name,position,start_time,end_time,q_number,operator_id,q_status) select q_name,position,start_time,end_time,q_number,operator_id,q_status from queue") or die("Error updating Archive : ".mysql_error());
			if($query_update_history)
			{
				$query_truncate = mysql_query("truncate table queue") or die ("Failed to clear queue table : ".mysql_error());
				echo "Done";
				header("location: manage_queue1.php");
			}

?>
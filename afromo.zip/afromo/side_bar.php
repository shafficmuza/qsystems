<title>Manage Queue</title>
 <div class="sidebar1">
    <ul class="nav">
      <li><a href="queue1.php">View Queue</a></li>
      <li><a href="add_queue.php">Add Queue</a></li>
      <li><a href="manage_queue1.php">Manage Queue</a></li>
      <li><a href="queue_display.php">Queue Display</a></li>
    </ul>
    <p> The above links demonstrate a basic </p>
    <!-- end .sidebar1 -->
   </div>
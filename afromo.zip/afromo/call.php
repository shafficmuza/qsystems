 <?php
        			require_once("config.php");
					
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
			
	//Sanitize the POST values  
	$status = clean($_GET['status']);
	$queue_id = clean($_GET['queue_id']);
	$position = clean($_GET['position']);
	
	$time = date("Y-m-d H:i:s");
	
			$query_update = mysql_query("update queue set q_status = '".$status."' where queue_id = '".$queue_id."'") or die("Error updating  : ".mysql_error());
			if($query_update){
				switch($status)
				{
			case "Started" : mysql_query("update queue set start_time = '".$time."' where queue_id = '".$queue_id."'") or die("Error updating  : ".mysql_error());
			break;
			case "Completed" :  mysql_query("update queue set end_time = '".$time."' where queue_id = '".$queue_id."'") or die("Error updating  : ".mysql_error());
			break;
			Default: "";
		
				}
				
				echo "Done";
				header("location: manage_queue1.php?queue_id=$queue_id&position=$position");
				}
		
?>
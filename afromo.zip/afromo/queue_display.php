<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Queue</title>
<style type="text/css">
.centerafro {
	text-align: center;
	color: #F00;
	font-weight: bold;
	font-style: italic;
}
.centerafroCounter {
	font-weight: bold;
	text-align: center;
	color: #060;
}
.centerafroCounter {
	font-size: 36px;
}
.centerafroCounter {
	font-size: large;
}
.centerafroCounter {
	font-size: xx-large;
}
.centerafroCounter {
	font-size: 42px;
}
.centerafroCounter {
	font-size: 42%;
}
.centerafroCounter {
	font-size: 42px;
}
.centerafroCounter {
	font-size: 80px;
}
.centerafroCounter {
	font-size: 120px;
}
.Welcome {
	text-align: center;
}
.Welcome marquee {
	font-weight: bold;
}
</style>
</head>

<body>
<p>&nbsp;</p>

<div id="auto_load_div"></div>
<table width="50%" border="0" align="center" bgcolor="#FFFFCC">
<tr>
    <td colspan="2"><p class="Welcome"><marquee direction="right" behavior="alternate">Welcome To Afro &amp; Mo</marquee></p></td>
  </tr>
  </table>
<script type="text/javascript" src="JS/jquery-latest.min.js"></script>
   <script>
      function auto_load(){
        $.ajax({
          url: "display_queue_content.php",
          cache: false,
          success: function(data){
             $("#auto_load_div").html(data);
          } 
        });
      }
 
      $(document).ready(function(){
 
        auto_load(); //Call auto_load() function when DOM is Ready
 
      });
 
      //Refresh auto_load() function after 2000 milliseconds
      setInterval(auto_load,2000);
   </script>

</body>
</html>

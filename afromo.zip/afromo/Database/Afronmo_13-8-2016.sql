-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 13, 2016 at 05:38 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `afromo`
--
CREATE DATABASE IF NOT EXISTS `afromo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `afromo`;

-- --------------------------------------------------------

--
-- Table structure for table `history_queue`
--

CREATE TABLE IF NOT EXISTS `history_queue` (
  `queue_id` int(11) NOT NULL AUTO_INCREMENT,
  `q_name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `start_time` varchar(100) NOT NULL,
  `end_time` varchar(100) NOT NULL,
  `q_number` varchar(100) NOT NULL,
  `operator_id` varchar(100) NOT NULL,
  `q_status` varchar(100) NOT NULL DEFAULT 'Waiting',
  `call` varchar(100) NOT NULL,
  PRIMARY KEY (`queue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `operators`
--

CREATE TABLE IF NOT EXISTS `operators` (
  `operator_id` int(11) NOT NULL AUTO_INCREMENT,
  `operator_name` varchar(100) NOT NULL,
  `operator_phone` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

CREATE TABLE IF NOT EXISTS `queue` (
  `queue_id` int(11) NOT NULL AUTO_INCREMENT,
  `q_name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `start_time` varchar(100) NOT NULL,
  `end_time` varchar(100) NOT NULL,
  `q_number` varchar(100) NOT NULL,
  `operator_id` varchar(100) NOT NULL,
  `q_status` varchar(100) NOT NULL DEFAULT 'Waiting',
  `call` varchar(100) NOT NULL,
  PRIMARY KEY (`queue_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `queue`
--

INSERT INTO `queue` (`queue_id`, `q_name`, `position`, `start_time`, `end_time`, `q_number`, `operator_id`, `q_status`, `call`) VALUES
(1, 'Gilbert', '3', '2016-08-13 17:34:06', '2016-08-13 17:34:17', '', '', 'Completed', ''),
(2, 'Shaffic', '5', '', '', '', '', 'Waiting', ''),
(3, 'Shaffic', '4', '', '', '', '', 'Waiting', ''),
(4, 'Jamilah', '10', '2016-08-13 17:37:11', '', '', '', 'Started', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
